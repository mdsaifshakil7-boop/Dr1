import { Link } from "@tanstack/react-router";
import { Dumbbell, MapPin, Phone, Mail, Clock, Instagram, Facebook, Twitter } from "lucide-react";
import { GYM } from "@/lib/gym";

export function SiteFooter() {
  return (
    <footer className="relative mt-24 border-t border-border/60">
      <div className="mx-auto max-w-7xl px-4 py-12">
        <div className="grid gap-10 md:grid-cols-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-[image:var(--gradient-primary)] text-white">
                <Dumbbell className="h-5 w-5" />
              </span>
              <div>
                <div className="font-display text-lg font-bold uppercase">IronForge</div>
                <div className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
                  Fitness
                </div>
              </div>
            </div>
            <p className="mt-4 text-sm text-muted-foreground">
              {GYM.tagline}. A community-powered gym built for serious training and real results.
            </p>
            <div className="mt-4 flex gap-2">
              <a aria-label="Instagram" href={GYM.instagram} target="_blank" rel="noreferrer" className="grid h-9 w-9 place-items-center rounded-full glass hover-lift">
                <Instagram className="h-4 w-4" />
              </a>
              <a aria-label="Facebook" href={GYM.facebook} target="_blank" rel="noreferrer" className="grid h-9 w-9 place-items-center rounded-full glass hover-lift">
                <Facebook className="h-4 w-4" />
              </a>
              <a aria-label="Twitter" href={GYM.twitter} target="_blank" rel="noreferrer" className="grid h-9 w-9 place-items-center rounded-full glass hover-lift">
                <Twitter className="h-4 w-4" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider">Explore</h4>
            <ul className="mt-4 space-y-2 text-sm">
              <li><Link to="/about" className="text-muted-foreground hover:text-primary">About</Link></li>
              <li><Link to="/programs" className="text-muted-foreground hover:text-primary">Programs</Link></li>
              <li><Link to="/trainers" className="text-muted-foreground hover:text-primary">Trainers</Link></li>
              <li><Link to="/schedule" className="text-muted-foreground hover:text-primary">Schedule</Link></li>
              <li><Link to="/membership" className="text-muted-foreground hover:text-primary">Membership</Link></li>
              <li><Link to="/blog" className="text-muted-foreground hover:text-primary">Blog</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider">Visit</h4>
            <ul className="mt-4 space-y-3 text-sm text-muted-foreground">
              <li className="flex gap-2"><MapPin className="h-4 w-4 mt-0.5 shrink-0 text-primary" />{GYM.address}</li>
              <li className="flex gap-2"><Phone className="h-4 w-4 mt-0.5 shrink-0 text-primary" />
                <a href={`tel:${GYM.phoneRaw}`}>{GYM.phone}</a>
              </li>
              <li className="flex gap-2"><Mail className="h-4 w-4 mt-0.5 shrink-0 text-primary" />{GYM.email}</li>
              <li className="flex gap-2"><Clock className="h-4 w-4 mt-0.5 shrink-0 text-primary" />{GYM.hoursShort}</li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider">Start Today</h4>
            <p className="mt-4 text-sm text-muted-foreground">
              Claim your free day pass and train with us, on us.
            </p>
            <Link
              to="/free-trial"
              className="mt-4 inline-flex items-center rounded-full btn-primary px-5 py-2.5 text-sm font-semibold"
            >
              Get Free Trial
            </Link>
          </div>
        </div>

        <div className="mt-10 flex flex-col gap-2 border-t border-border/60 pt-6 text-xs text-muted-foreground sm:flex-row sm:justify-between">
          <p>© {new Date().getFullYear()} {GYM.name}. All rights reserved.</p>
          <p>{GYM.tagline}.</p>
        </div>
      </div>
    </footer>
  );
}
