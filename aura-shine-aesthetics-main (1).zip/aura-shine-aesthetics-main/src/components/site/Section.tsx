import { ReactNode } from "react";

export function Section({
  eyebrow,
  title,
  subtitle,
  children,
  className = "",
  center = true,
}: {
  eyebrow?: string;
  title?: string;
  subtitle?: string;
  children: ReactNode;
  className?: string;
  center?: boolean;
}) {
  return (
    <section className={`section-pad ${className}`}>
      <div className="mx-auto max-w-7xl px-4">
        {(eyebrow || title || subtitle) && (
          <div className={`mb-12 ${center ? "text-center max-w-3xl mx-auto" : ""}`}>
            {eyebrow && (
              <span className="inline-block rounded-full glass px-4 py-1 text-xs font-semibold uppercase tracking-[0.25em] text-primary">
                {eyebrow}
              </span>
            )}
            {title && (
              <h2 className="mt-4 text-balance font-display text-4xl font-bold uppercase sm:text-5xl">
                {title}
              </h2>
            )}
            {subtitle && (
              <p className="mt-4 text-pretty text-base text-muted-foreground sm:text-lg">{subtitle}</p>
            )}
          </div>
        )}
        {children}
      </div>
    </section>
  );
}

export function PageHero({
  eyebrow,
  title,
  subtitle,
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
}) {
  return (
    <section className="relative pt-32 pb-12">
      <div className="mx-auto max-w-7xl px-4 text-center">
        {eyebrow && (
          <span className="inline-block rounded-full glass px-4 py-1 text-xs font-semibold uppercase tracking-[0.25em] text-primary">
            {eyebrow}
          </span>
        )}
        <h1 className="mt-4 font-display text-5xl font-bold uppercase tracking-tight sm:text-7xl">
          <span className="gradient-text">{title}</span>
        </h1>
        {subtitle && <p className="mx-auto mt-5 max-w-2xl text-lg text-muted-foreground">{subtitle}</p>}
      </div>
    </section>
  );
}
