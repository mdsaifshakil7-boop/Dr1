import { Link } from "@tanstack/react-router";
import { Flame } from "lucide-react";

export function FloatingCTA() {
  return (
    <div className="fixed bottom-4 right-4 z-40 flex flex-col items-end gap-3">
      <Link
        to="/free-trial"
        className="inline-flex items-center gap-2 rounded-full btn-primary px-5 py-3 text-sm font-semibold shadow-lg"
      >
        <Flame className="h-4 w-4" />
        Free Trial
      </Link>
    </div>
  );
}
