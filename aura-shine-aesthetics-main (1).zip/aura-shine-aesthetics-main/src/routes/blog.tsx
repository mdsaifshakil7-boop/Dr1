import { createFileRoute, Link } from "@tanstack/react-router";
import { Section, PageHero } from "@/components/site/Section";
import { ArrowRight, Calendar, Clock } from "lucide-react";
import { GYM } from "@/lib/gym";
import { posts } from "@/lib/content";

export const Route = createFileRoute("/blog")({
  head: () => ({
    meta: [
      { title: `Blog — Training & Nutrition Guides | ${GYM.name}` },
      { name: "description", content: `Expert training, nutrition, and recovery guides from the coaches at ${GYM.name}.` },
      { property: "og:title", content: `Blog | ${GYM.name}` },
      { property: "og:url", content: "/blog" },
    ],
    links: [{ rel: "canonical", href: "/blog" }],
  }),
  component: BlogPage,
});

function BlogPage() {
  return (
    <>
      <PageHero eyebrow="Blog" title="Train smarter" subtitle="Training, nutrition, and recovery insights from our coaches." />

      <Section>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {posts.map((p, i) => (
            <article key={i} className="group glass overflow-hidden rounded-3xl p-3 hover-lift">
              <div className="overflow-hidden rounded-2xl">
                <img src={p.image} alt={p.title} className="aspect-[4/3] w-full object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy" />
              </div>
              <div className="p-4">
                <div className="flex items-center justify-between text-xs">
                  <span className="rounded-full glass px-3 py-1 font-semibold text-primary">{p.cat}</span>
                  <span className="flex items-center gap-1 text-muted-foreground"><Calendar className="h-3 w-3" />{p.date}</span>
                </div>
                <h3 className="mt-3 font-display text-lg font-bold uppercase leading-snug">{p.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{p.excerpt}</p>
                <div className="mt-3 flex items-center justify-between">
                  <span className="inline-flex items-center gap-1 text-sm font-semibold text-primary">
                    Read more <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
                  </span>
                  <span className="flex items-center gap-1 text-xs text-muted-foreground"><Clock className="h-3 w-3" />{p.readTime}</span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </Section>

      <Section>
        <div className="glass rounded-3xl p-8 text-center sm:p-12">
          <h3 className="font-display text-3xl font-bold uppercase">Ready to put it into practice?</h3>
          <p className="mt-2 text-muted-foreground">Claim your free trial and train with our coaches.</p>
          <Link to="/free-trial" className="mt-6 inline-flex rounded-full btn-primary px-6 py-3 text-sm font-semibold">
            Get Free Trial
          </Link>
        </div>
      </Section>
    </>
  );
}
