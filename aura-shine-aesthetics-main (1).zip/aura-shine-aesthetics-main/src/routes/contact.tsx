import { createFileRoute, Link } from "@tanstack/react-router";
import { Section, PageHero } from "@/components/site/Section";
import { MapPin, Phone, Mail, Clock, MessageCircle } from "lucide-react";
import { GYM } from "@/lib/gym";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: `Contact — ${GYM.name}` },
      { name: "description", content: `Visit ${GYM.name} at ${GYM.address}. Call ${GYM.phone} or email us to learn more.` },
      { property: "og:title", content: `Contact | ${GYM.name}` },
      { property: "og:url", content: "/contact" },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
  component: ContactPage,
});

function ContactPage() {
  return (
    <>
      <PageHero eyebrow="Contact" title="Come train with us" subtitle="Visit, call, or stop by — we'd love to meet you." />

      <Section>
        <div className="grid gap-6 lg:grid-cols-[1fr_1.4fr]">
          <div className="space-y-4">
            <Card icon={MapPin} title="Address">{GYM.address}</Card>
            <Card icon={Phone} title="Phone">
              <a href={`tel:${GYM.phoneRaw}`} className="font-semibold gradient-text">{GYM.phone}</a>
            </Card>
            <Card icon={Mail} title="Email">
              <a href={`mailto:${GYM.email}`} className="font-semibold gradient-text">{GYM.email}</a>
            </Card>
            <Card icon={Clock} title="Hours">{GYM.hours}</Card>
            <Link to="/free-trial" className="block rounded-3xl glass p-6 hover-lift">
              <div className="flex items-center gap-3">
                <span className="grid h-10 w-10 place-items-center rounded-xl bg-[image:var(--gradient-primary)] text-white">
                  <MessageCircle className="h-4 w-4" />
                </span>
                <h3 className="font-display text-lg font-bold uppercase">Ready to start?</h3>
              </div>
              <p className="mt-3 text-sm text-muted-foreground">Claim your free day pass and train with us, on us.</p>
            </Link>
          </div>

          <div className="glass overflow-hidden rounded-3xl p-2">
            <iframe
              title={`${GYM.name} location map`}
              src={`https://www.google.com/maps?q=${GYM.mapsQuery}&output=embed`}
              loading="lazy"
              className="h-[500px] w-full rounded-2xl"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </Section>
    </>
  );
}

function Card({ icon: Icon, title, children }: { icon: React.ElementType; title: string; children: React.ReactNode }) {
  return (
    <div className="glass rounded-3xl p-6 hover-lift">
      <div className="flex items-center gap-3">
        <span className="grid h-10 w-10 place-items-center rounded-xl bg-[image:var(--gradient-primary)] text-white">
          <Icon className="h-4 w-4" />
        </span>
        <h3 className="font-display text-lg font-bold uppercase">{title}</h3>
      </div>
      <div className="mt-3 text-sm text-muted-foreground">{children}</div>
    </div>
  );
}
