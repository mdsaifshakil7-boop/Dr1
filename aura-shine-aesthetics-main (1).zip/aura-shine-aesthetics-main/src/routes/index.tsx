import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Dumbbell,
  Flame,
  HeartPulse,
  ArrowRight,
  Check,
  Star,
  Quote,
  Users,
  Trophy,
  Clock,
  Zap,
} from "lucide-react";
import { Section } from "@/components/site/Section";
import { GYM, goals } from "@/lib/gym";
import { stats, programs, trainers, plans, testimonials, images } from "@/lib/content";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: `${GYM.name} — ${GYM.tagline} | Austin, TX` },
      { name: "description", content: `Strength training, HIIT, powerlifting, and personal coaching at ${GYM.name} in Austin, TX. Claim your free trial today.` },
      { property: "og:title", content: `${GYM.name} — ${GYM.tagline}` },
      { property: "og:description", content: "Austin's premier strength and conditioning gym." },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: HomePage,
});

const goalIcons = { Dumbbell, Flame, HeartPulse } as const;

function HomePage() {
  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <img src={images.heroImg} alt="" className="h-full w-full object-cover opacity-40" />
          <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/50 to-background" />
        </div>
        <div className="mx-auto max-w-7xl px-4 pt-12 pb-24 sm:pt-20 sm:pb-32">
          <div className="grid gap-10 lg:grid-cols-2 lg:items-center">
            <div className="animate-fade-in">
              <span className="inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.25em] text-primary">
                <Flame className="h-3.5 w-3.5" /> {GYM.name}
              </span>
              <h1 className="mt-6 font-display text-6xl font-bold uppercase leading-[0.95] tracking-tight sm:text-8xl">
                Forge Your<br />
                <span className="gradient-text">Strongest</span><br />
                Self
              </h1>
              <p className="mt-6 text-lg text-muted-foreground sm:text-xl">
                Strength · Conditioning · Powerlifting · Hypertrophy — coached by experts who actually train.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link to="/free-trial" className="inline-flex items-center gap-2 rounded-full btn-primary px-6 py-3.5 text-sm font-semibold">
                  Claim Free Trial <ArrowRight className="h-4 w-4" />
                </Link>
                <Link to="/programs" className="inline-flex items-center gap-2 rounded-full glass px-6 py-3.5 text-sm font-semibold">
                  Explore Programs
                </Link>
              </div>
              <div className="mt-10 flex items-center gap-6 text-sm">
                <div className="flex">
                  {[...Array(5)].map((_, i) => <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />)}
                </div>
                <span className="text-muted-foreground"><b className="text-foreground">4.9</b> from 800+ member reviews</span>
              </div>
            </div>

            <div className="relative">
              <div className="glass animate-float rounded-3xl p-3 hover-lift">
                <img src={images.gymImg1} alt={`${GYM.name} training floor`} className="aspect-[4/5] w-full rounded-2xl object-cover" />
              </div>
              <div className="absolute -bottom-6 -left-6 glass rounded-2xl p-4 max-w-[220px] hidden sm:block">
                <div className="text-xs uppercase tracking-wider text-muted-foreground">This week</div>
                <div className="mt-1 font-display text-2xl font-bold gradient-text">45 Classes</div>
                <div className="mt-1 text-xs text-muted-foreground">From 5 AM to 9 PM</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* STATS */}
      <Section>
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {stats.map((s) => (
            <div key={s.label} className="glass rounded-3xl p-6 text-center hover-lift">
              <div className="font-display text-4xl font-bold gradient-text sm:text-5xl">{s.value}</div>
              <div className="mt-1 text-sm text-muted-foreground">{s.label}</div>
            </div>
          ))}
        </div>
      </Section>

      {/* GOALS */}
      <Section eyebrow="Your Goals" title="Train for your why" subtitle="Whatever you're chasing, we build the program around it.">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {goals.map((g) => {
            const Icon = goalIcons[g.icon as keyof typeof goalIcons] ?? Dumbbell;
            return (
              <Link to="/programs" key={g.id} className="group glass rounded-3xl p-6 hover-lift">
                <span className="grid h-14 w-14 place-items-center rounded-2xl bg-[image:var(--gradient-primary)] text-white">
                  <Icon className="h-6 w-6" />
                </span>
                <h3 className="mt-5 font-display text-xl font-bold uppercase">{g.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{g.blurb}</p>
                <span className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-primary">
                  Explore <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
                </span>
              </Link>
            );
          })}
        </div>
      </Section>

      {/* PROGRAMS PREVIEW */}
      <Section eyebrow="Programs" title="Built to make you better" subtitle="Coached, periodized, and scalable to every level.">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {programs.slice(0, 6).map((p) => (
            <Link to="/programs" key={p.id} className="group glass overflow-hidden rounded-3xl p-3 hover-lift">
              <div className="overflow-hidden rounded-2xl">
                <img src={p.image} alt={p.name} className="aspect-[4/3] w-full object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy" />
              </div>
              <div className="p-4">
                <div className="flex items-center justify-between text-xs">
                  <span className="rounded-full glass px-3 py-1 font-semibold text-primary">{p.category}</span>
                  <span className="flex items-center gap-1 text-muted-foreground"><Clock className="h-3 w-3" />{p.duration}</span>
                </div>
                <h3 className="mt-3 font-display text-xl font-bold uppercase">{p.name}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{p.description}</p>
              </div>
            </Link>
          ))}
        </div>
      </Section>

      {/* WHY US */}
      <Section eyebrow="Why IronForge" title="More than a gym. A system that works.">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { icon: Users, title: "Expert Coaches", desc: "Certified, competitive, and invested in your progress." },
            { icon: Trophy, title: "Proven Results", desc: "Thousands of members reaching PRs and goals every year." },
            { icon: Zap, title: "Premium Equipment", desc: "Rogue, Eleiko, and Hammer Strength across a 12,000 sq ft floor." },
            { icon: Clock, title: "Open Early, Late", desc: "5 AM to 11 PM on weekdays so you can train on your schedule." },
          ].map((f) => (
            <div key={f.title} className="glass rounded-3xl p-5 hover-lift">
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[image:var(--gradient-primary)] text-white">
                <f.icon className="h-5 w-5" />
              </span>
              <h4 className="mt-4 font-display text-lg font-bold uppercase">{f.title}</h4>
              <p className="mt-2 text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* TRAINERS PREVIEW */}
      <Section eyebrow="The Team" title="Coaches who train, and train hard" subtitle="Led by competitive athletes who live what they teach.">
        <div className="grid gap-6 md:grid-cols-3">
          {trainers.map((t) => (
            <Link to="/trainers" key={t.id} className="group glass overflow-hidden rounded-3xl p-3 hover-lift">
              <div className="overflow-hidden rounded-2xl">
                <img src={t.image} alt={t.name} className="aspect-[4/5] w-full object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy" />
              </div>
              <div className="p-4 text-center">
                <h3 className="font-display text-xl font-bold uppercase">{t.name}</h3>
                <p className="mt-1 text-sm font-semibold text-primary">{t.specialty}</p>
              </div>
            </Link>
          ))}
        </div>
      </Section>

      {/* MEMBERSHIP TEASER */}
      <Section eyebrow="Membership" title="Plans that fit your grind" subtitle="No contracts. Cancel anytime. Start with a free trial.">
        <div className="grid gap-6 md:grid-cols-3">
          {plans.map((p) => (
            <div
              key={p.id}
              className={`glass relative rounded-3xl p-6 hover-lift ${p.popular ? "ring-2 ring-primary" : ""}`}
            >
              {p.popular && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-[image:var(--gradient-primary)] px-4 py-1 text-xs font-semibold uppercase tracking-wider text-white">
                  Most Popular
                </span>
              )}
              <h3 className="font-display text-2xl font-bold uppercase">{p.name}</h3>
              <div className="mt-3 flex items-baseline gap-1">
                <span className="font-display text-5xl font-bold gradient-text">${p.price}</span>
                <span className="text-sm text-muted-foreground">{p.cadence}</span>
              </div>
              <p className="mt-3 text-sm text-muted-foreground">{p.description}</p>
              <ul className="mt-6 space-y-3">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm">
                    <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-[image:var(--gradient-primary)] text-white">
                      <Check className="h-3 w-3" />
                    </span>
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
              <Link
                to="/membership"
                className={`mt-6 inline-flex w-full items-center justify-center rounded-full px-5 py-3 text-sm font-semibold ${p.popular ? "btn-primary" : "glass"}`}
              >
                Choose {p.name}
              </Link>
            </div>
          ))}
        </div>
        <div className="mt-8 text-center">
          <Link to="/membership" className="inline-flex items-center gap-2 rounded-full glass px-5 py-2.5 text-sm font-semibold">
            Compare all plans <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </Section>

      {/* TESTIMONIALS */}
      <Section eyebrow="Member Stories" title="Real people. Real results.">
        <div className="grid gap-6 md:grid-cols-3">
          {testimonials.slice(0, 3).map((t) => (
            <div key={t.name} className="glass rounded-3xl p-6 hover-lift">
              <Quote className="h-7 w-7 text-primary" />
              <p className="mt-4 text-base">"{t.text}"</p>
              <div className="mt-6 flex items-center justify-between">
                <div>
                  <div className="font-semibold">{t.name}</div>
                  <div className="text-xs text-muted-foreground">{t.role}</div>
                </div>
                <span className="rounded-full bg-[image:var(--gradient-primary)] px-3 py-1 text-xs font-semibold text-white">{t.result}</span>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-8 text-center">
          <Link to="/about" className="inline-flex items-center gap-2 rounded-full glass px-5 py-2.5 text-sm font-semibold">
            Read more stories <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </Section>

      {/* CTA */}
      <Section>
        <div className="relative overflow-hidden rounded-3xl bg-[image:var(--gradient-primary)] p-8 text-center text-white sm:p-16 shadow-[var(--shadow-glow)]">
          <Flame className="mx-auto h-10 w-10 opacity-90" />
          <h2 className="mt-4 font-display text-4xl font-bold uppercase sm:text-6xl">Your first session is on us</h2>
          <p className="mx-auto mt-4 max-w-xl text-white/90">Train free for a day. No card, no pressure. Just show up.</p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link to="/free-trial" className="rounded-full bg-white px-6 py-3 text-sm font-semibold text-primary hover-lift">Claim Free Trial</Link>
            <Link to="/contact" className="rounded-full bg-white/15 backdrop-blur px-6 py-3 text-sm font-semibold ring-1 ring-white/30">
              {GYM.phone}
            </Link>
          </div>
        </div>
      </Section>
    </>
  );
}
