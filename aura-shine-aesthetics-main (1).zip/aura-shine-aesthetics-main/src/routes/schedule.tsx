import { createFileRoute, Link } from "@tanstack/react-router";
import { Section, PageHero } from "@/components/site/Section";
import { Clock, User } from "lucide-react";
import { GYM } from "@/lib/gym";
import { schedule } from "@/lib/content";

export const Route = createFileRoute("/schedule")({
  head: () => ({
    meta: [
      { title: `Class Schedule — ${GYM.name}` },
      { name: "description", content: `Weekly class schedule at ${GYM.name}: strength, HIIT, hypertrophy, powerlifting, Olympic lifting, mobility, and more.` },
      { property: "og:title", content: `Schedule | ${GYM.name}` },
      { property: "og:url", content: "/schedule" },
    ],
    links: [{ rel: "canonical", href: "/schedule" }],
  }),
  component: SchedulePage,
});

const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

function SchedulePage() {
  return (
    <>
      <PageHero eyebrow="Schedule" title="This week's classes" subtitle="Drop in. Work hard. Get better." />

      <Section>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {days.map((day) => {
            const slots = schedule.filter((s) => s.day === day);
            return (
              <div key={day} className="glass rounded-3xl p-5 hover-lift">
                <h3 className="font-display text-xl font-bold uppercase">{day}</h3>
                <div className="mt-4 space-y-3">
                  {slots.map((s, i) => (
                    <div key={i} className="rounded-2xl bg-white/50 p-3 dark:bg-white/5">
                      <div className="flex items-center justify-between">
                        <span className="font-display text-lg font-bold text-primary">{s.time}</span>
                        <span className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Clock className="h-3 w-3" />{s.duration}
                        </span>
                      </div>
                      <div className="mt-1 font-semibold">{s.className}</div>
                      <div className="mt-0.5 flex items-center gap-1 text-xs text-muted-foreground">
                        <User className="h-3 w-3" />{s.trainer}
                      </div>
                    </div>
                  ))}
                  {slots.length === 0 && (
                    <div className="rounded-2xl bg-white/40 p-3 text-sm text-muted-foreground dark:bg-white/5">
                      No scheduled classes.
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </Section>

      <Section>
        <div className="glass rounded-3xl p-8 text-center sm:p-12">
          <h3 className="font-display text-3xl font-bold uppercase">Want unlimited classes?</h3>
          <p className="mt-2 text-muted-foreground">Athlete and Elite members get unlimited access to every class, every week.</p>
          <Link to="/membership" className="mt-6 inline-flex rounded-full btn-primary px-6 py-3 text-sm font-semibold">
            View Plans
          </Link>
        </div>
      </Section>
    </>
  );
}
