import { createFileRoute, Link } from "@tanstack/react-router";
import { Section, PageHero } from "@/components/site/Section";
import { Check, X, ArrowRight } from "lucide-react";
import { GYM } from "@/lib/gym";
import { plans } from "@/lib/content";

export const Route = createFileRoute("/membership")({
  head: () => ({
    meta: [
      { title: `Membership — ${GYM.name}` },
      { name: "description", content: `Simple, flexible membership plans at ${GYM.name}. No contracts, cancel anytime. Start with a free trial.` },
      { property: "og:title", content: `Membership | ${GYM.name}` },
      { property: "og:url", content: "/membership" },
    ],
    links: [{ rel: "canonical", href: "/membership" }],
  }),
  component: MembershipPage,
});

const allFeatures = [
  "Full gym floor access",
  "2 group classes / week",
  "Unlimited group classes",
  "Locker room & showers",
  "Fitness assessment",
  "Mobile app access",
  "1 personal training session / month",
  "4 personal training sessions / month",
  "Custom programming",
  "Nutrition starter guide",
  "Body composition tracking",
  "Recovery zone access",
  "Recovery sauna & ice bath",
  "Guest passes (2/month)",
  "Priority class booking",
];

function MembershipPage() {
  return (
    <>
      <PageHero eyebrow="Membership" title="Find your fit" subtitle="No contracts. No hidden fees. Cancel anytime." />

      <Section>
        <div className="grid gap-6 md:grid-cols-3">
          {plans.map((p) => (
            <div
              key={p.id}
              className={`glass relative rounded-3xl p-6 hover-lift ${p.popular ? "ring-2 ring-primary" : ""}`}
            >
              {p.popular && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-[image:var(--gradient-primary)] px-4 py-1 text-xs font-semibold uppercase tracking-wider text-white">
                  Most Popular
                </span>
              )}
              <h3 className="font-display text-3xl font-bold uppercase">{p.name}</h3>
              <div className="mt-3 flex items-baseline gap-1">
                <span className="font-display text-5xl font-bold gradient-text">${p.price}</span>
                <span className="text-sm text-muted-foreground">{p.cadence}</span>
              </div>
              <p className="mt-3 text-sm text-muted-foreground">{p.description}</p>
              <ul className="mt-6 space-y-3">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-2 text-sm">
                    <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-[image:var(--gradient-primary)] text-white">
                      <Check className="h-3 w-3" />
                    </span>
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
              <Link
                to="/free-trial"
                className={`mt-6 inline-flex w-full items-center justify-center rounded-full px-5 py-3 text-sm font-semibold ${p.popular ? "btn-primary" : "glass"}`}
              >
                Get {p.name}
              </Link>
            </div>
          ))}
        </div>
      </Section>

      {/* COMPARISON TABLE */}
      <Section eyebrow="Compare" title="Plan comparison">
        <div className="glass overflow-hidden rounded-3xl">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="p-4 text-left font-semibold">Feature</th>
                  {plans.map((p) => (
                    <th key={p.id} className="p-4 text-center font-display font-bold uppercase">{p.name}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {allFeatures.map((f) => (
                  <tr key={f} className="border-b border-border/50 last:border-b-0">
                    <td className="p-4 text-muted-foreground">{f}</td>
                    {plans.map((p) => {
                      const has = p.features.includes(f);
                      return (
                        <td key={p.id} className="p-4 text-center">
                          {has ? (
                            <span className="mx-auto grid h-6 w-6 place-items-center rounded-full bg-[image:var(--gradient-primary)] text-white">
                              <Check className="h-3.5 w-3.5" />
                            </span>
                          ) : (
                            <X className="mx-auto h-4 w-4 text-muted-foreground/50" />
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </Section>

      {/* FAQ-ish */}
      <Section>
        <div className="grid gap-4 md:grid-cols-3">
          {[
            { q: "Can I freeze my membership?", a: "Yes. Freeze anytime for up to 3 months per year, no questions asked." },
            { q: "Is there an initiation fee?", a: "No. You only pay the monthly rate. No sign-up fees, ever." },
            { q: "Can I bring a friend?", a: "Athlete and Elite members get guest passes. Or send them to our free trial." },
          ].map((f) => (
            <div key={f.q} className="glass rounded-3xl p-6 hover-lift">
              <h4 className="font-display text-lg font-bold uppercase">{f.q}</h4>
              <p className="mt-2 text-sm text-muted-foreground">{f.a}</p>
            </div>
          ))}
        </div>
      </Section>

      <Section>
        <div className="relative overflow-hidden rounded-3xl bg-[image:var(--gradient-primary)] p-8 text-center text-white sm:p-16">
          <h2 className="font-display text-4xl font-bold uppercase sm:text-5xl">Try before you commit</h2>
          <p className="mx-auto mt-4 max-w-xl text-white/90">Train free for a full day. Meet the coaches. See the floor.</p>
          <Link to="/free-trial" className="mt-8 inline-flex items-center gap-2 rounded-full bg-white px-6 py-3 text-sm font-semibold text-primary hover-lift">
            Claim Free Trial <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </Section>
    </>
  );
}
