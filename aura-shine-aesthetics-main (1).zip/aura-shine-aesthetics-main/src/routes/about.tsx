import { createFileRoute, Link } from "@tanstack/react-router";
import { Section, PageHero } from "@/components/site/Section";
import { Heart, Trophy, ShieldCheck, Dumbbell, ArrowRight } from "lucide-react";
import { GYM } from "@/lib/gym";
import { images, testimonials, stats } from "@/lib/content";
import { Star } from "lucide-react";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: `About — ${GYM.name} | Austin, TX` },
      { name: "description", content: `The story behind ${GYM.name}: a community-powered gym built for serious training and real results in Austin, TX.` },
      { property: "og:title", content: `About ${GYM.name}` },
      { property: "og:url", content: "/about" },
    ],
    links: [{ rel: "canonical", href: "/about" }],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <>
      <PageHero eyebrow="About Us" title="Built by lifters, for lifters" subtitle="A gym where coaching, community, and equipment meet serious intent." />

      {/* STORY */}
      <Section>
        <div className="grid gap-10 lg:grid-cols-2 lg:items-center">
          <div className="glass rounded-3xl p-3 hover-lift">
            <img src={images.gymImg1} alt={`${GYM.name} training floor`} className="aspect-[4/3] w-full rounded-2xl object-cover" loading="lazy" />
          </div>
          <div>
            <h2 className="font-display text-4xl font-bold uppercase">Our story</h2>
            <p className="mt-4 text-muted-foreground">
              {GYM.name} started in a 600 sq ft garage with one barbell, two squat stands, and a simple belief —
              that real coaching and a community that shows up beats fancy machines and shiny sales pitches every time.
            </p>
            <p className="mt-4 text-muted-foreground">
              Eight years later we've grown into a 12,000 sq ft strength and conditioning facility with 24 coaches,
              45+ weekly classes, and thousands of members who've hit PRs, run marathons, stepped on stage,
              and rediscovered what their bodies can do.
            </p>
            <p className="mt-4 text-muted-foreground">
              We're not a fitness factory. We're a training center. Every program is coached, every member is known,
              and every session has intent.
            </p>
          </div>
        </div>
      </Section>

      {/* VALUES */}
      <Section eyebrow="What we stand for" title="Our principles">
        <div className="grid gap-6 md:grid-cols-3">
          {[
            { icon: Heart, title: "Community First", text: "You're not a number here. You're a member with a name, a goal, and a crew." },
            { icon: Trophy, title: "Results Driven", text: "We measure success in PRs, not check-ins. Programming that actually progresses." },
            { icon: ShieldCheck, title: "Train Smart", text: "Form, technique, and recovery come before ego. Longevity is the goal." },
          ].map((c) => (
            <div key={c.title} className="glass rounded-3xl p-6 hover-lift">
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[image:var(--gradient-primary)] text-white">
                <c.icon className="h-5 w-5" />
              </span>
              <h3 className="mt-4 font-display text-xl font-bold uppercase">{c.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{c.text}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* FACILITY */}
      <Section eyebrow="The Facility" title="12,000 sq ft of serious iron" subtitle="Everything you need and nothing you don't.">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[
            "8 competition power racks",
            "Rogue & Eleiko barbells",
            "Dedicated Olympic lifting platform",
            "Conditioning turf with sleds",
            "Full dumbbell range up to 150 lb",
            "Recovery zone with sauna & ice bath",
            "Functional fitness rig",
            "Cardio equipment row",
            "Private coaching studio",
          ].map((f) => (
            <div key={f} className="glass rounded-2xl p-5 flex items-center gap-3 hover-lift">
              <Dumbbell className="h-5 w-5 text-primary" />
              <span className="font-medium">{f}</span>
            </div>
          ))}
        </div>
      </Section>

      {/* STATS */}
      <Section>
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {stats.map((s) => (
            <div key={s.label} className="glass rounded-3xl p-6 text-center hover-lift">
              <div className="font-display text-4xl font-bold gradient-text sm:text-5xl">{s.value}</div>
              <div className="mt-1 text-sm text-muted-foreground">{s.label}</div>
            </div>
          ))}
        </div>
      </Section>

      {/* MEMBER STORIES */}
      <Section eyebrow="Member Stories" title="Transformations that stick">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((t) => (
            <div key={t.name} className="glass rounded-3xl p-6 hover-lift">
              <div className="flex items-center gap-3">
                <img src={t.image} alt={t.name} className="h-12 w-12 rounded-full object-cover" loading="lazy" />
                <div>
                  <div className="font-semibold">{t.name}</div>
                  <div className="text-xs text-muted-foreground">{t.role}</div>
                </div>
              </div>
              <div className="mt-3 flex">
                {[...Array(5)].map((_, i) => <Star key={i} className="h-3.5 w-3.5 fill-yellow-400 text-yellow-400" />)}
              </div>
              <p className="mt-3 text-sm">"{t.text}"</p>
              <span className="mt-4 inline-block rounded-full bg-[image:var(--gradient-primary)] px-3 py-1 text-xs font-semibold text-white">{t.result}</span>
            </div>
          ))}
        </div>
      </Section>

      {/* CTA */}
      <Section>
        <div className="relative overflow-hidden rounded-3xl bg-[image:var(--gradient-primary)] p-8 text-center text-white sm:p-16">
          <h2 className="font-display text-4xl font-bold uppercase sm:text-5xl">Come see for yourself</h2>
          <p className="mx-auto mt-4 max-w-xl text-white/90">Tour the gym, meet a coach, and train free for a day.</p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link to="/free-trial" className="rounded-full bg-white px-6 py-3 text-sm font-semibold text-primary hover-lift">Claim Free Trial</Link>
            <Link to="/contact" className="inline-flex items-center gap-2 rounded-full bg-white/15 backdrop-blur px-6 py-3 text-sm font-semibold ring-1 ring-white/30">
              Get directions <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </Section>
    </>
  );
}
