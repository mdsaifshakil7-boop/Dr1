import { createFileRoute } from "@tanstack/react-router";
import { Section, PageHero } from "@/components/site/Section";
import { useState } from "react";
import { Check, CircleAlert as AlertCircle, Calendar, Clock, Loader as Loader2 } from "lucide-react";
import { GYM } from "@/lib/gym";
import { supabase } from "@/lib/supabase";

export const Route = createFileRoute("/free-trial")({
  head: () => ({
    meta: [
      { title: `Free Trial — ${GYM.name}` },
      { name: "description", content: `Train free for a day at ${GYM.name}. No card, no pressure. Book your free trial session now.` },
      { property: "og:title", content: `Free Trial | ${GYM.name}` },
      { property: "og:url", content: "/free-trial" },
    ],
    links: [{ rel: "canonical", href: "/free-trial" }],
  }),
  component: FreeTrialPage,
});

const goals = [
  "Build Strength",
  "Lose Weight",
  "Build Muscle",
  "Conditioning",
  "Powerlifting / Competition",
  "Just trying it out",
];

const experienceLevels = ["Beginner", "Intermediate", "Advanced"];

const timeSlots = ["Early morning (5–8 AM)", "Morning (8–11 AM)", "Midday (11 AM–2 PM)", "Afternoon (2–5 PM)", "Evening (5–8 PM)", "Late (8–11 PM)"];

function FreeTrialPage() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    goal: "",
    experience_level: "",
    preferred_date: "",
    preferred_time: "",
    message: "",
  });
  const [status, setStatus] = useState<"idle" | "submitting" | "success" | "error">("idle");
  const [error, setError] = useState<string>("");

  function update<K extends keyof typeof form>(k: K, v: string) {
    setForm((f) => ({ ...f, [k]: v }));
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim() || !form.email.trim() || !form.phone.trim()) {
      setError("Please fill in your name, email, and phone.");
      setStatus("error");
      return;
    }

    setStatus("submitting");
    setError("");

    try {
      const { error: dbError } = await supabase.from("free_trials").insert({
        name: form.name.trim(),
        email: form.email.trim(),
        phone: form.phone.trim(),
        goal: form.goal || null,
        experience_level: form.experience_level || null,
        preferred_date: form.preferred_date || null,
        preferred_time: form.preferred_time || null,
        message: form.message || null,
      });

      if (dbError) throw dbError;
      setStatus("success");
    } catch (err) {
      console.error(err);
      setError("Something went wrong submitting your request. Please try again or call us.");
      setStatus("error");
    }
  }

  if (status === "success") {
    return (
      <>
        <PageHero eyebrow="Free Trial" title="You're in" subtitle="We'll see you on the platform." />
        <Section>
          <div className="mx-auto max-w-lg glass rounded-3xl p-8 text-center">
            <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-[image:var(--gradient-primary)] text-white">
              <Check className="h-7 w-7" />
            </span>
            <h3 className="mt-6 font-display text-3xl font-bold uppercase">Thank you, {form.name.split(" ")[0]}!</h3>
            <p className="mt-3 text-muted-foreground">
              Your free trial request is in. Our team will confirm your slot via email within a few hours.
              We can't wait to train with you.
            </p>
            <div className="mt-6 grid gap-2 text-sm text-muted-foreground">
              <div className="flex items-center justify-center gap-2">
                <Calendar className="h-4 w-4 text-primary" />
                {form.preferred_date || "Date to be confirmed"}
              </div>
              {form.preferred_time && (
                <div className="flex items-center justify-center gap-2">
                  <Clock className="h-4 w-4 text-primary" />
                  {form.preferred_time}
                </div>
              )}
            </div>
            <a href={`tel:${GYM.phoneRaw}`} className="mt-6 inline-flex rounded-full glass px-5 py-2.5 text-sm font-semibold">
              Need to change? Call {GYM.phone}
            </a>
          </div>
        </Section>
      </>
    );
  }

  return (
    <>
      <PageHero eyebrow="Free Trial" title="Train free for a day" subtitle="No card. No contract. Just show up and lift." />

      <Section>
        <div className="grid gap-8 lg:grid-cols-[1.6fr_1fr]">
          <div className="glass rounded-3xl p-6 sm:p-8">
            <form onSubmit={onSubmit} className="grid gap-4 sm:grid-cols-2">
              <Field label="Full Name" required>
                <input
                  required
                  value={form.name}
                  maxLength={100}
                  disabled={status === "submitting"}
                  onChange={(e) => update("name", e.target.value)}
                  className={inputCls}
                  placeholder="Your name"
                />
              </Field>
              <Field label="Phone" required>
                <input
                  required
                  type="tel"
                  value={form.phone}
                  maxLength={30}
                  disabled={status === "submitting"}
                  onChange={(e) => update("phone", e.target.value)}
                  className={inputCls}
                  placeholder="+1 (555) 000-0000"
                />
              </Field>
              <Field label="Email" required>
                <input
                  required
                  type="email"
                  value={form.email}
                  maxLength={150}
                  disabled={status === "submitting"}
                  onChange={(e) => update("email", e.target.value)}
                  className={inputCls}
                  placeholder="you@email.com"
                />
              </Field>
              <Field label="Primary Goal">
                <select
                  value={form.goal}
                  disabled={status === "submitting"}
                  onChange={(e) => update("goal", e.target.value)}
                  className={inputCls}
                >
                  <option value="">Select a goal</option>
                  {goals.map((g) => <option key={g} value={g}>{g}</option>)}
                </select>
              </Field>
              <Field label="Experience Level">
                <select
                  value={form.experience_level}
                  disabled={status === "submitting"}
                  onChange={(e) => update("experience_level", e.target.value)}
                  className={inputCls}
                >
                  <option value="">Select level</option>
                  {experienceLevels.map((l) => <option key={l} value={l}>{l}</option>)}
                </select>
              </Field>
              <Field label="Preferred Date">
                <input
                  type="date"
                  value={form.preferred_date}
                  disabled={status === "submitting"}
                  onChange={(e) => update("preferred_date", e.target.value)}
                  className={inputCls}
                />
              </Field>
              <Field label="Preferred Time" className="sm:col-span-2">
                <select
                  value={form.preferred_time}
                  disabled={status === "submitting"}
                  onChange={(e) => update("preferred_time", e.target.value)}
                  className={inputCls}
                >
                  <option value="">Select a time window</option>
                  {timeSlots.map((t) => <option key={t} value={t}>{t}</option>)}
                </select>
              </Field>
              <div className="sm:col-span-2">
                <Field label="Anything else?">
                  <textarea
                    value={form.message}
                    maxLength={500}
                    rows={4}
                    disabled={status === "submitting"}
                    onChange={(e) => update("message", e.target.value)}
                    className={inputCls}
                    placeholder="Injuries, questions, specific goals..."
                  />
                </Field>
              </div>

              {status === "error" && (
                <div className="sm:col-span-2 flex items-start gap-2 rounded-2xl bg-destructive/10 p-3 text-sm text-destructive">
                  <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <div className="sm:col-span-2">
                <button
                  type="submit"
                  disabled={status === "submitting"}
                  className="flex w-full items-center justify-center gap-2 rounded-full btn-primary px-6 py-4 text-sm font-bold uppercase tracking-wider disabled:opacity-60 disabled:pointer-events-none"
                >
                  {status === "submitting" ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" /> Submitting...
                    </>
                  ) : (
                    "Claim My Free Trial"
                  )}
                </button>
                <p className="mt-3 text-center text-xs text-muted-foreground">By submitting, you agree to be contacted by {GYM.name}. No spam, ever.</p>
              </div>
            </form>
          </div>

          <aside className="space-y-4">
            <div className="glass rounded-3xl p-6">
              <Calendar className="h-6 w-6 text-primary" />
              <h3 className="mt-3 font-display text-xl font-bold uppercase">What's included</h3>
              <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
                <li>· Full day gym floor access</li>
                <li>· One group class of your choice</li>
                <li>· Intro chat with a coach</li>
                <li>· Locker room & shower access</li>
              </ul>
            </div>
            <div className="glass rounded-3xl p-6">
              <h3 className="font-display text-xl font-bold uppercase">Prefer to talk?</h3>
              <a href={`tel:${GYM.phoneRaw}`} className="mt-3 block text-lg font-semibold gradient-text">{GYM.phone}</a>
              <p className="mt-2 text-sm text-muted-foreground">{GYM.hours}</p>
            </div>
            <div className="glass rounded-3xl p-6">
              <h3 className="font-display text-xl font-bold uppercase">Where we are</h3>
              <p className="mt-3 text-sm text-muted-foreground">{GYM.address}</p>
            </div>
          </aside>
        </div>
      </Section>
    </>
  );
}

const inputCls =
  "w-full rounded-2xl border border-border bg-white/70 px-4 py-3 text-sm outline-none transition focus:border-primary focus:bg-white focus:ring-4 focus:ring-primary/15 dark:bg-white/10 dark:text-foreground dark:placeholder:text-muted-foreground";

function Field({
  label,
  children,
  required,
  className = "",
}: {
  label: string;
  children: React.ReactNode;
  required?: boolean;
  className?: string;
}) {
  return (
    <label className={`block ${className}`}>
      <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">
        {label}{required && <span className="text-primary"> *</span>}
      </span>
      {children}
    </label>
  );
}
