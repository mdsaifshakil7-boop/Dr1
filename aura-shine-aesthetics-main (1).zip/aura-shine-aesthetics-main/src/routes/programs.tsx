import { createFileRoute, Link } from "@tanstack/react-router";
import { Section, PageHero } from "@/components/site/Section";
import { Clock, Zap, ArrowRight, Check } from "lucide-react";
import { GYM } from "@/lib/gym";
import { programs, images } from "@/lib/content";

export const Route = createFileRoute("/programs")({
  head: () => ({
    meta: [
      { title: `Programs — ${GYM.name}` },
      { name: "description", content: `Strength training, HIIT conditioning, hypertrophy, powerlifting, Olympic lifting, and functional fitness at ${GYM.name}.` },
      { property: "og:title", content: `Programs | ${GYM.name}` },
      { property: "og:url", content: "/programs" },
    ],
    links: [{ rel: "canonical", href: "/programs" }],
  }),
  component: ProgramsPage,
});

const intensityColor = { Low: "text-success", Medium: "text-warning", High: "text-destructive" } as const;

function ProgramsPage() {
  return (
    <>
      <PageHero eyebrow="Programs" title="Train with intent" subtitle="Every program is coached, periodized, and scalable — from day one to record day." />

      <Section>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {programs.map((p) => (
            <div key={p.id} className="group glass overflow-hidden rounded-3xl p-3 hover-lift">
              <div className="overflow-hidden rounded-2xl">
                <img src={p.image} alt={p.name} className="aspect-[4/3] w-full object-cover transition-transform duration-700 group-hover:scale-105" loading="lazy" />
              </div>
              <div className="p-4">
                <div className="flex items-center justify-between text-xs">
                  <span className="rounded-full glass px-3 py-1 font-semibold text-primary">{p.category}</span>
                  <span className={`flex items-center gap-1 font-semibold ${intensityColor[p.intensity]}`}>
                    <Zap className="h-3 w-3" /> {p.intensity}
                  </span>
                </div>
                <h3 className="mt-3 font-display text-xl font-bold uppercase">{p.name}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{p.description}</p>
                <div className="mt-3 flex items-center gap-4 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{p.duration}</span>
                </div>
                <Link to="/free-trial" className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-primary">
                  Try it free <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
                </Link>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* WHAT'S INCLUDED */}
      <Section eyebrow="Every Program Includes" title="Coaching that goes the distance">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[
            "Structured periodized programming",
            "Hands-on technical coaching",
            "Progress tracking & assessments",
            "Mobility & warm-up protocols",
            "Nutrition starter guidance",
            "Access to member community",
          ].map((f) => (
            <div key={f} className="glass rounded-2xl p-4 flex items-center gap-3 hover-lift">
              <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-[image:var(--gradient-primary)] text-white">
                <Check className="h-3.5 w-3.5" />
              </span>
              <span className="font-medium">{f}</span>
            </div>
          ))}
        </div>
      </Section>

      {/* CTA */}
      <Section>
        <div className="relative overflow-hidden rounded-3xl bg-[image:var(--gradient-primary)] p-8 text-center text-white sm:p-16">
          <img src={images.gymImg2} alt="" className="absolute inset-0 h-full w-full object-cover opacity-20" />
          <div className="relative">
            <h2 className="font-display text-4xl font-bold uppercase sm:text-5xl">Not sure where to start?</h2>
            <p className="mx-auto mt-4 max-w-xl text-white/90">Book a free intro session and we'll match you with the right program and coach.</p>
            <Link to="/free-trial" className="mt-8 inline-flex rounded-full bg-white px-6 py-3 text-sm font-semibold text-primary hover-lift">
              Book Free Intro
            </Link>
          </div>
        </div>
      </Section>
    </>
  );
}
