import { createFileRoute, Link } from "@tanstack/react-router";
import { Section, PageHero } from "@/components/site/Section";
import { Award, Check, ArrowRight } from "lucide-react";
import { GYM } from "@/lib/gym";
import { trainers } from "@/lib/content";

export const Route = createFileRoute("/trainers")({
  head: () => ({
    meta: [
      { title: `Trainers — ${GYM.name}` },
      { name: "description", content: `Meet the certified coaches of ${GYM.name}: strength, conditioning, hypertrophy, powerlifting, and Olympic lifting specialists.` },
      { property: "og:title", content: `Trainers | ${GYM.name}` },
      { property: "og:url", content: "/trainers" },
    ],
    links: [{ rel: "canonical", href: "/trainers" }],
  }),
  component: TrainersPage,
});

function TrainersPage() {
  return (
    <>
      <PageHero eyebrow="The Team" title="Coaches who compete" subtitle="Certified, experienced, and still in the trenches themselves." />

      <Section>
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {trainers.map((t) => (
            <div key={t.id} className="glass rounded-3xl p-4 hover-lift">
              <div className="overflow-hidden rounded-2xl">
                <img src={t.image} alt={t.name} className="aspect-[4/5] w-full object-cover" loading="lazy" />
              </div>
              <div className="p-3">
                <h3 className="font-display text-2xl font-bold uppercase">{t.name}</h3>
                <p className="mt-1 text-sm font-semibold text-primary">{t.specialty}</p>
                <p className="mt-3 text-sm text-muted-foreground">{t.bio}</p>
                <div className="mt-4">
                  <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    <Award className="h-4 w-4 text-primary" /> Certifications
                  </div>
                  <ul className="mt-2 space-y-2">
                    {t.certifications.map((c) => (
                      <li key={c} className="flex items-center gap-2 text-sm">
                        <span className="grid h-5 w-5 place-items-center rounded-full bg-[image:var(--gradient-primary)] text-white">
                          <Check className="h-3 w-3" />
                        </span>
                        {c}
                      </li>
                    ))}
                  </ul>
                </div>
                <Link to="/free-trial" className="mt-5 inline-flex items-center gap-1 text-sm font-semibold text-primary">
                  Train with {t.name.split(" ")[0]} <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </div>
            </div>
          ))}
        </div>
      </Section>

      <Section>
        <div className="glass rounded-3xl p-8 text-center sm:p-12">
          <h3 className="font-display text-3xl font-bold uppercase">Want 1-on-1 coaching?</h3>
          <p className="mt-2 text-muted-foreground">Personal training packages start with a free consultation.</p>
          <Link to="/membership" className="mt-6 inline-flex rounded-full btn-primary px-6 py-3 text-sm font-semibold">
            View Membership Options
          </Link>
        </div>
      </Section>
    </>
  );
}
