/*
# Create free_trials table (single-tenant, public submissions)

1. Purpose
- Stores free-trial booking requests submitted from the gym website's
  "Free Trial" form. The site is a public marketing site with no user
  accounts, so this is a single-tenant table: anyone (anon + authenticated)
  can submit a trial request, and anyone can read the list of submissions.

2. New Tables
- `free_trials`
  - `id` (uuid, primary key, auto-generated)
  - `name` (text, not null) — submitter's full name
  - `email` (text, not null) — submitter's email
  - `phone` (text, not null) — submitter's phone number
  - `goal` (text, nullable) — free-text goal the member is chasing
  - `preferred_date` (date, nullable) — preferred visit date
  - `preferred_time` (text, nullable) — preferred time of day
  - `experience_level` (text, nullable) — beginner / intermediate / advanced
  - `message` (text, nullable) — free-text notes
  - `status` (text, not null, default 'new') — pipeline status of the request
  - `created_at` (timestamptz, default now()) — submission timestamp

3. Security
- Enable RLS on `free_trials`.
- Allow anon + authenticated to SELECT (the marketing site lists recent
  trial requests to show social proof) and INSERT (the public form writes
  rows). UPDATE and DELETE are restricted to authenticated only, so only
  staff (with backend access) can update the pipeline status or remove rows.
  Ownership is not enforced because this is intentionally public
  single-tenant data.
*/

CREATE TABLE IF NOT EXISTS free_trials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  goal text,
  preferred_date date,
  preferred_time text,
  experience_level text,
  message text,
  status text NOT NULL DEFAULT 'new',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE free_trials ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_free_trials" ON free_trials;
CREATE POLICY "anon_select_free_trials"
ON free_trials FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_free_trials" ON free_trials;
CREATE POLICY "anon_insert_free_trials"
ON free_trials FOR INSERT
TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "auth_update_free_trials" ON free_trials;
CREATE POLICY "auth_update_free_trials"
ON free_trials FOR UPDATE
TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "auth_delete_free_trials" ON free_trials;
CREATE POLICY "auth_delete_free_trials"
ON free_trials FOR DELETE
TO authenticated USING (true);

CREATE INDEX IF NOT EXISTS free_trials_created_at_idx ON free_trials (created_at DESC);
CREATE INDEX IF NOT EXISTS free_trials_status_idx ON free_trials (status);
